$(function(){
    var bubbles = $('.center').addClass('fade-in');
});