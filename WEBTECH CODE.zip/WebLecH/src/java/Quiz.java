/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author luaplien
 */
@WebServlet(name = "Quiz", urlPatterns = {"/Quiz"})
public class Quiz extends HttpServlet {

   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      PrintWriter out=response.getWriter();  
     int points = 0;
     String [] questions = new String[21];
     questions[0] = request.getParameter("1");
     questions[1] = request.getParameter("2");
     questions[2] = request.getParameter("3");
     questions[3] = request.getParameter("4");
     questions[4] = request.getParameter("5");      
     questions[5] = request.getParameter("6");
     questions[6] = request.getParameter("7");   
     questions[7] = request.getParameter("8");
     questions[8] = request.getParameter("9");   
     questions[9] = request.getParameter("10");
     questions[10] = request.getParameter("11");     
     questions[11] = request.getParameter("12");
     questions[12] = request.getParameter("13");
     questions[13] = request.getParameter("14");
     questions[14] = request.getParameter("15");
     questions[15] = request.getParameter("16");
     questions[16] = request.getParameter("17");
     questions[17] = request.getParameter("18");
     questions[18] = request.getParameter("19");
     questions[19] = request.getParameter("20");
     questions[20] = request.getParameter("21");
     String [] answers = new String[21];
     answers[0] = "RequestDispatcher";
     answers[1] = "forward() method";
     answers[2] = "include() method";
     answers[3] = "sendRedirect() method";
     answers[4] = "Instantiation";      
     answers[5] = "Initialization";      
     answers[6] = "Request Handling";   
     answers[7] = "Destruction";
     answers[8] = " init() method";     
     answers[9] = "service() method";
     answers[10] = "Error Handling";     
     answers[11] = "<error-code> ";      
     answers[12] = "<exception-type>";      
     answers[13] = "<location>";
     answers[14] = "ServletException";
     answers[15] = "IOException";     
     answers[16] = "RuntimeException";      
     answers[17] = "Status code 403";      
     answers[18] = "Data definition language";
     answers[19] = "Data manipulation language";
     answers[20] = "HTTPServlet";
     for(int i=0;i<answers.length;i++){
         if(answers[i].equalsIgnoreCase(questions[i])){
             points++;
         }        
     }
      request.setAttribute("score",points);
      request.setAttribute("maxScore",answers.length);
      request.getRequestDispatcher("QuizServlet-logout.jsp").include(request, response);	
      
     
    }

}
