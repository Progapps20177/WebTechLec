/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author luaplien
 */
@WebServlet(name = "PhpQuiz", urlPatterns = {"/PhpQuiz"})
public class PhpQuiz extends HttpServlet {

   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      PrintWriter out=response.getWriter();  
     int points = 0;
     String [] questions = new String[12];
     questions[0] = request.getParameter("1");
     questions[1] = request.getParameter("2");
     questions[2] = request.getParameter("3");
     questions[3] = request.getParameter("4");
     questions[4] = request.getParameter("5");      
     questions[5] = request.getParameter("6");
     questions[6] = request.getParameter("7");   
     questions[7] = request.getParameter("8");
     questions[8] = request.getParameter("9");   
     questions[9] = request.getParameter("10");
     questions[10] = request.getParameter("11");     
     questions[11] = request.getParameter("12");


     String [] answers = new String[12];
     answers[0] = "HTTP/";
     answers[1] = "Location:";
     answers[2] = "Replace";
     answers[3] = "Http response code";
     answers[4] = "Superglobal";      
     answers[5] = "$Globals";      
     answers[6] = "$SERVER";   
     answers[7] = "$GET";
     answers[8] = "$POST";     
     answers[9] = "$SESSION";
     answers[10] = "Heredoc";     
     answers[11] = "Nowdoc"; 
     for(int i=0;i<answers.length;i++){
         if(answers[i].equalsIgnoreCase(questions[i])){
             points++;
         }        
     }
      request.setAttribute("score",points);
      request.setAttribute("maxScore",answers.length);
      request.getRequestDispatcher("QuizPHP-logout.jsp").include(request, response);	
      
     
    }

}
