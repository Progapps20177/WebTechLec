import java.io.IOException;  
import java.io.PrintWriter;  
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse; 
import javax.servlet.http.HttpSession;


@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
                           throws ServletException, IOException {

        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
                     
        String name=request.getParameter("email");  
        String password=request.getParameter("password");                          
        try{
            String user = "";
            String pass = " ";
        //loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver");
        //creating connection with the database 
           Connection  connect=DriverManager.getConnection ("jdbc:mysql://localhost:3306/students?user=root&pwd=");
           
           String exists = "SELECT email,pass FROM students_info";
           Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
           ResultSet rs = stmt.executeQuery(exists);
            while (rs.next()) {
            String usertest = rs.getString("email");
            String passtest = rs.getString("pass");
               if(usertest.equals(name) && passtest.equals(password)){
                    user = rs.getString("email");
                    pass = rs.getString("pass");
               }
            }
            Cookie ck=new Cookie("name",name); 
            ck.setMaxAge(60 * 60 *24);
               if(user.equals(name) && pass.equals(password)){
                   response.addCookie(ck); 
                   response.sendRedirect("index");
                   return;
               }
                          

         
   
        
        }
        catch(ClassNotFoundException | SQLException se)
        {
            System.out.println(se);
        }  
          
        out.close();  
    }  
  
}