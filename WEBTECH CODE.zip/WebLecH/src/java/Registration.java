import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet(name = "Registration", urlPatterns = {"/Registration"})
public class Registration extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String pass = request.getParameter("password");
        try{
        //loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver");
   //creating connection with the database 
           Connection  connect=DriverManager.getConnection ("jdbc:mysql://localhost:3306/students?user=root&pwd=");
           
           String exists = "SELECT email FROM students_info";
           Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
           
           ResultSet rs = stmt.executeQuery(exists);
            while (rs.next()) {
            String studemail = rs.getString("email");
               if(email.equals(studemail)){
                   out.println("Registration Failed!");
                   request.getRequestDispatcher("register-failed.html").include(request, response); 
               }
            }
           String insert = "INSERT INTO students_info(name,email,pass) VALUES (?,?,?)";
           PreparedStatement ps = connect.prepareStatement(insert);

           ps.setString(1, name);
           ps.setString(2, email);
           ps.setString(3, pass);
          

           int i = ps.executeUpdate();
           if(i>0){
               request.getRequestDispatcher("index.html").include(request, response);
           }
           
        
        }
        catch(ClassNotFoundException | SQLException se)
        {
            System.out.println(se);
        }
	
      }
  }